<?php  
    require 'func_peminjam.php';

    $id = $_GET ['id_anggota'];

$datapeminjam    =   query_view ("SELECT * FROM tb_peminjam WHERE id_anggota= $id")[0];

if (isset ($_POST["simpan"])) {
    # code...
    if (update ($_POST) > 0 ) {
        # code...
        echo "
        <script>
            alert ('berhasil diubah');
            document.location.href ='data_peminjam.php';
        </script>
        ";
    } else {
        # code...
        echo "
        <script>
            alert ('gagal diubah');
            document.location.href ='data_peminjam.php';
        </script>
        ";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Halaman Admin</title>

  <!-- Map -->
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin=""/>
    <script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js" integrity="sha256-WBkoXOwTeyKclOHuWtc+i2uENFpDZ9YPdf5Hf+D7ewM=" crossorigin=""></script>

  <!-- Custom fonts for this template-->
  <link href="../assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="../assets/css/sb-admin-2.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/css/bootstrap-datepicker.css">
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<!-- Javascript Bootstrap -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js">
</script>


</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../index.php">
        <div class="sidebar-brand-icon">
          <i class="fas fa-globe"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Adminweb</div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item">
        <a class="nav-link" href="../index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Nav Item - Charts -->
      <li class="nav-item">
        <a class="nav-link" href="../manajemen_admin/data_user.php">
          <i class="fas fa-fw fa-user"></i>
          <span>Data Admin</span></a>
      </li>

      <!-- Nav Item - Tables -->
      <li class="nav-item active">
        <a class="nav-link" href="data_peminjam.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Data Peminjam</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="../manajemen_transaksi/data_transaksi.php">
          <i class="fas fa-fw fa-calculator"></i>
          <span>Data Transaksi</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="../manajemen_galeri/data_galeri.php">
          <i class="fas fa-fw fa-adjust"></i>
          <span>Data Galeri</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->
          <h4>GIS Koperasi</h4>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">


            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Admin</span>
                <img class="img-profile rounded-circle" src="https://source.unsplash.com/QAB-WJcbgJk/60x60">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Form Ubah Data</h1>
            <form method="POST" action="" enctype="multipart/form-data">
             <div class="card mb-4">
                <div class="card-header">
                  Ubah Data Peminjam
                </div>
              <div class="row">
                <div class="col-md-6">
                  <div class="card-body">
                    <input type="hidden" name="id_anggota" value="<?php echo $datapeminjam["id_anggota"];?>">
                    <input type="hidden" name="fotolama" value="<?php echo $datapeminjam["foto"];?>">
                  <div class="form-group">
                        <label for="exampleInputEmail1">Nama Peminjam</label>
                    <input type="text" class="form-control" id="peminjam" aria-describedby="emailHelp" placeholder="Masukan nama peminjam" name="nama" required value="<?php echo $datapeminjam["nama"];?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Tempat Lahir</label>
                    <input type="text" class="form-control" id="alamat" placeholder="Masukan tempat lahir" name="tmp_lahir" required value="<?php echo $datapeminjam["tmp_lahir"];?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Tanggal Lahir</label>
                    <input type="date" name="tgl_lahir" class="form-control" required value="<?php echo $datapeminjam["tgl_lahir"];?>" />
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Alamat</label>
                    <input type="text" class="form-control" id="alamat" placeholder="Masukan alamat peminjam" name="alamat" required value="<?php echo $datapeminjam["alamat"];?>">
                  </div>
                   <div class="form-group">
                    <label class="my-1 mr-2" for="inlineFormCustomSelectPref">Pilih Jenis Usaha</label>
                      <select class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" name="id_kategori" >
                        <option selected>--Pilih Kategori--</option>
                        <?php 
                                            $sql_pot = mysqli_query ($conn, "SELECT * FROM tb_kategori") or die 
                                                    (mysqli_error ($conn));
                                                    while ($data_pot  =   mysqli_fetch_array($sql_pot)){
                                                        if ($data_pot['id_kategori'] == $datapeminjam['id_kategori']) {
                                                            ?>
                                                            <option value="<?php echo $data_pot['id_kategori'];?>" selected>
                                                            <?php echo $data_pot['nama_kategori'];?></option>
                                                            <?php
                                                        } else { 
                                                            ?>
                                                            <option value="<?php echo $data_pot['id_kategori'];?>">
                                                            <?php echo $data_pot['nama_kategori'];?></option>
                                                            <?php
                                                            }
                                                        }
                                        ?>
                      </select>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Saldo</label>
                    <input type="number" class="form-control" id="alamat" placeholder="Masukan saldo peminjam" name="saldo" required value="<?php echo $datapeminjam["saldo"];?>">
                  </div>
                   <div class="form-group">
                    <label class="my-1 mr-2" for="datepicker">Tanggal Gabung</label><br>
                       <input type="date" name="tgl_gabung" class="form-control" required value="<?php echo $datapeminjam["tgl_gabung"];?>" />
                  </div>
                   <div class="form-group">
                    <label for="exampleInputPassword1">Lama Pinjam</label>
                    <input type="number" class="form-control" id="alamat" placeholder="Masukan jangka waktu (hari) peminjaman" name="lama_pinjam" required value="<?php echo $datapeminjam["lama_pinjam"];?>">
                  </div>
                  <div class="form-group">
                        <label for="exampleInputEmail1">Nama Wali</label>
                    <input type="text" class="form-control" id="nama_wali" aria-describedby="emailHelp" placeholder="Masukan nama wali" name="nama_wali" required value="<?php echo $datapeminjam["nama_wali"];?>">
                  </div>
                  <div class="form-group">
                        <label for="exampleInputEmail1">Nama NIK Wali</label>
                    <input type="number" class="form-control" id="nik" aria-describedby="emailHelp" placeholder="Masukan NIK wali" name="nik" required value="<?php echo $datapeminjam["nik"];?>">
                  </div>
                  <div class="form-group">
                    <label class="my-1 mr-2" for="inlineFormCustomSelectPref">Pilih Status Hubungan</label>
                      <select class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" name="id_keluarga" >
                        <option selected>--Pilih Status Hubungan--</option>
                        <?php 
                        $sql_pot = mysqli_query ($conn, "SELECT * FROM tb_keluarga") or die 
                        (mysqli_error ($conn));
                        while ($data_pot  =   mysqli_fetch_array($sql_pot)){
                          if ($data_pot['id_keluarga'] == $datapeminjam['id_keluarga']) {
                            ?>
                            <option value="<?php echo $data_pot['id_keluarga'];?>" selected>
                            <?php echo $data_pot['hubungan'];?></option>
                            <?php
                            } else { 
                              ?>
                              <option value="<?php echo $data_pot['id_keluarga'];?>">
                              <?php echo $data_pot['hubungan'];?></option>
                              <?php
                              }
                            }
                            ?>
                      </select>
                  </div>
                  <div class="form-group">
                    <label class="my-1 mr-2" for="inlineFormCustomSelectPref">Pilih Status</label>
                      <select class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" name="status">
                        <option selected>Pilih...</option>
                        <?php
                        if ($datapeminjam["status"] == "Aktif") {
                          ?>
                           <option value="Aktif" selected>Aktif</option>
                           <option value="Nonaktif">Nonaktif</option>
                           <?php
                        } else {
                          ?>
                          <option value="Nonaktif" selected>Nonaktif</option>
                          <option value="Aktif">Aktif</option>
                          <?php
                        }
                        ?>
                      </select>
                  </div>
                 
                    <div class="form-group row">
                     <div class="col">
                        <label>Longitude</label>
                        <input type="text" class="form-control" id="Lng" name="longitude" required value ="<?php echo $datapeminjam["longitude"];?>">
                      </div>
                      <div class="col">
                        <label>Latitude</label>
                        <input type="text" class="form-control" id="Lat" name="latitude" required value ="<?php echo $datapeminjam["latitude"];?>">
                      </div>
                    </div>

                    <div class="form-group">
                        <img src="../assets/img/<?php echo $datapeminjam ['foto'] ?>" width="150" style="padding-bottom: 7px; margin-top: 10px;">
                        <div class="custom-file">
                      <input type="file" class="custom-file-input" id="customFile" name="foto">
                      <label class="custom-file-label" for="customFile">Pilih Gambar</label>
                    </div>
                    </div>
                  <button type="Submit" class="btn btn-success" name="simpan">Simpan</button>
                  <a href="data_peminjam.php"><button type="Submit" class="btn btn-danger" name="simpan">Batal</button></a>
                </div>

              </div>
                 <div class="col-md-6">
                  <div class="form-group">
                     <!-- Maps  -->
                            <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDEeLj0uio_AwmUva2x_R4wsNkJTazpXLc&callback=initMap" async defer></script>
                             <div class="card" style="margin: 10px;">  
                                <div class="card-body">
                                    <div class="content" id="map" style="height: 400px; width:auto;"></div>
                                    <script type="text/javascript">
                                var tileLayer = new L.TileLayer('http://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png',{
                                      attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, &copy; <a href="http://cartodb.com/attributions">CartoDB</a>'
                                    });

                                    var map = new L.Map('map', {
                                      'center': [<?php echo $datapeminjam ['latitude'] ?>,<?php echo $datapeminjam ['longitude'] ?>],
                                      'zoom': 15,
                                      'layers': [tileLayer]
                                    });

                                    var marker = L.marker([<?php echo $datapeminjam ['latitude'] ?>,<?php echo $datapeminjam ['longitude'] ?>],{
                                      draggable: true
                                    }).addTo(map);

                                    marker.on('dragend', function (e) {
                                      document.getElementById('Lat').value = marker.getLatLng().lat;
                                      document.getElementById('Lng').value = marker.getLatLng().lng;
                                    });
                            </script>
                                </div>
                            </div>
                  </div>
                </div>
                    </form>
                    
              </div>
            </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2019</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="../logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="../assets/vendor/jquery/jquery.min.js"></script>
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../assets/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="../assets/js/sb-admin-2.min.js"></script>

</body>

</html>
